class some_object:
    class inner:
        pass
