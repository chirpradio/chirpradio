
# these get replaced by fakes in the doctest
    
def current_user(*args):
    raise NotImplementedError
    
def login(*args):
    raise NotImplementedError