
----------------
fudge.inspector
----------------

.. automodule:: fudge.inspector
   
.. autoclass:: fudge.inspector.ValueInspector
   :members: