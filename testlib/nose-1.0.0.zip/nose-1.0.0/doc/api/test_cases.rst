Test Cases
==========

.. automodule :: nose.case
   :members:

.. autoclass :: nose.failure.Failure
   :members:
