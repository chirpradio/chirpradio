def b():
    pass
