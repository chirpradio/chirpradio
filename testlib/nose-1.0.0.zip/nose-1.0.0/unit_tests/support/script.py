#!/usr/bin/env python

print "FAIL"
