# test file in test dir in a package
def test_foo():
    pass
