
# these get replaced by fakes in the doctest
    
def login(*args):
    raise NotImplementedError