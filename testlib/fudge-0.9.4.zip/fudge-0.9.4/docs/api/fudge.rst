
-----
fudge
-----

.. automodule:: fudge

.. autofunction:: fudge.clear_calls

.. autofunction:: fudge.verify

.. autofunction:: fudge.with_fakes

.. autoclass:: fudge.Fake
   :members:
   
.. autoclass:: fudge.FakeDeclarationError
   :members: