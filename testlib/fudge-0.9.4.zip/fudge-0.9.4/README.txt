
Fudge is a module for replacing real objects with fakes (mocks, stubs, etc) while testing.

Documentation is available at http://farmdev.com/projects/fudge/ or else, you can build it from source like this::
    
    $ easy_install Sphinx
    $ cd docs
    $ make html

then open _build/html/index.html in your web browser.

To run tests, you need Sphinx and Nose::
    
    $ easy_install Sphinx nose
    $ ./run_tests.sh

