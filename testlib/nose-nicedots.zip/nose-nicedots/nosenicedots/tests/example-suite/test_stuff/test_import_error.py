
# SyntaxError:
raise :foo: bar